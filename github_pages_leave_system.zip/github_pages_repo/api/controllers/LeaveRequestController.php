<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\LeaveRequest;
use App\Models\LeaveType;
use App\Models\LeaveBalance;
use App\Models\ApprovalHistory;
use App\Models\ApprovalStage;
use App\Models\Notification;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class LeaveRequestController extends Controller
{
    /**
     * عرض قائمة طلبات الإجازة للمستخدم الحالي
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $user = Auth::user();
        $leaveRequests = LeaveRequest::where('user_id', $user->user_id)
            ->with(['leaveType', 'approvals.stage', 'approvals.approver'])
            ->orderBy('created_at', 'desc')
            ->get();

        return response()->json([
            'status' => 'success',
            'data' => $leaveRequests
        ]);
    }

    /**
     * عرض طلبات الإجازة التي تحتاج إلى موافقة من المستخدم الحالي
     *
     * @return \Illuminate\Http\Response
     */
    public function pendingApprovals()
    {
        $user = Auth::user();
        
        if (!$user->isManager()) {
            return response()->json([
                'status' => 'error',
                'message' => 'غير مصرح لك بالوصول إلى هذه الصفحة'
            ], 403);
        }

        // الحصول على طلبات الإجازة التي تحتاج إلى موافقة من المدير المباشر
        $pendingRequests = [];
        
        if ($user->isHrManager()) {
            // مدير الموارد البشرية يرى جميع الطلبات في مرحلة موافقة الموارد البشرية
            $hrStage = ApprovalStage::where('stage_name', 'موافقة الموارد البشرية')->first();
            
            if ($hrStage) {
                $pendingApprovals = ApprovalHistory::where('stage_id', $hrStage->stage_id)
                    ->where('status', 'pending')
                    ->with(['leaveRequest.user', 'leaveRequest.leaveType', 'stage'])
                    ->get();
                
                foreach ($pendingApprovals as $approval) {
                    $pendingRequests[] = $approval->leaveRequest;
                }
            }
        } else {
            // المدير يرى طلبات موظفيه فقط
            $subordinates = $user->subordinates->pluck('user_id')->toArray();
            
            $managerStage = ApprovalStage::where('stage_name', 'موافقة المدير المباشر')->first();
            
            if ($managerStage && !empty($subordinates)) {
                $leaveRequests = LeaveRequest::whereIn('user_id', $subordinates)
                    ->where('status', 'pending')
                    ->with(['user', 'leaveType', 'approvals'])
                    ->get();
                
                foreach ($leaveRequests as $request) {
                    $pendingApproval = $request->approvals()
                        ->where('stage_id', $managerStage->stage_id)
                        ->where('status', 'pending')
                        ->first();
                    
                    if ($pendingApproval) {
                        $pendingRequests[] = $request;
                    }
                }
            }
        }

        return response()->json([
            'status' => 'success',
            'data' => $pendingRequests
        ]);
    }

    /**
     * إنشاء طلب إجازة جديد
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'leave_type_id' => 'required|exists:leave_types,leave_type_id',
            'start_date' => 'required|date|after_or_equal:today',
            'end_date' => 'required|date|after_or_equal:start_date',
            'reason' => 'required|string|max:500',
            'attachment' => 'nullable|file|mimes:pdf,doc,docx,jpg,jpeg,png|max:2048',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => 'بيانات غير صالحة',
                'errors' => $validator->errors()
            ], 422);
        }

        $user = Auth::user();
        $leaveType = LeaveType::find($request->leave_type_id);
        
        // حساب عدد أيام الإجازة
        $startDate = new \DateTime($request->start_date);
        $endDate = new \DateTime($request->end_date);
        $interval = $startDate->diff($endDate);
        $totalDays = $interval->days + 1; // شامل يوم البداية والنهاية
        
        // التحقق من رصيد الإجازة
        $leaveBalance = LeaveBalance::where('user_id', $user->user_id)
            ->where('leave_type_id', $request->leave_type_id)
            ->where('year', date('Y'))
            ->first();
        
        if (!$leaveBalance) {
            // إنشاء رصيد إجازة جديد إذا لم يكن موجوداً
            $leaveBalance = new LeaveBalance([
                'user_id' => $user->user_id,
                'leave_type_id' => $request->leave_type_id,
                'year' => date('Y'),
                'total_days' => $leaveType->default_days,
                'used_days' => 0,
                'remaining_days' => $leaveType->default_days,
                'carried_over' => 0
            ]);
            $leaveBalance->save();
        }
        
        if ($leaveType->is_paid && $leaveBalance->remaining_days < $totalDays) {
            return response()->json([
                'status' => 'error',
                'message' => 'رصيد الإجازة غير كافٍ'
            ], 400);
        }
        
        // معالجة المرفق إذا وجد
        $attachmentPath = null;
        if ($request->hasFile('attachment')) {
            $attachment = $request->file('attachment');
            $fileName = time() . '_' . $attachment->getClientOriginalName();
            $attachmentPath = $attachment->storeAs('attachments', $fileName, 'public');
        }
        
        // إنشاء طلب الإجازة
        $leaveRequest = new LeaveRequest([
            'user_id' => $user->user_id,
            'leave_type_id' => $request->leave_type_id,
            'start_date' => $request->start_date,
            'end_date' => $request->end_date,
            'total_days' => $totalDays,
            'reason' => $request->reason,
            'attachment_path' => $attachmentPath,
            'status' => 'pending'
        ]);
        
        $leaveRequest->save();
        
        // إنشاء سجل الموافقات
        $firstStage = ApprovalStage::orderBy('order_num', 'asc')->first();
        
        if ($firstStage) {
            $approval = new ApprovalHistory([
                'request_id' => $leaveRequest->request_id,
                'stage_id' => $firstStage->stage_id,
                'approver_id' => $user->manager_id,
                'status' => 'pending'
            ]);
            
            $approval->save();
            
            // إرسال إشعار للمدير
            if ($user->manager_id) {
                $notification = new Notification([
                    'user_id' => $user->manager_id,
                    'title' => 'طلب إجازة جديد',
                    'message' => 'قام ' . $user->full_name . ' بتقديم طلب إجازة جديد يحتاج إلى موافقتك',
                    'related_to' => 'leave_request',
                    'related_id' => $leaveRequest->request_id,
                    'is_read' => false
                ]);
                
                $notification->save();
            }
        }
        
        return response()->json([
            'status' => 'success',
            'message' => 'تم إنشاء طلب الإجازة بنجاح',
            'data' => $leaveRequest
        ], 201);
    }

    /**
     * عرض تفاصيل طلب إجازة محدد
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $user = Auth::user();
        $leaveRequest = LeaveRequest::with(['leaveType', 'user', 'approvals.stage', 'approvals.approver'])
            ->find($id);
        
        if (!$leaveRequest) {
            return response()->json([
                'status' => 'error',
                'message' => 'طلب الإجازة غير موجود'
            ], 404);
        }
        
        // التحقق من الصلاحيات
        if ($leaveRequest->user_id !== $user->user_id && 
            !$user->isHrManager() && 
            !in_array($leaveRequest->user_id, $user->subordinates->pluck('user_id')->toArray())) {
            return response()->json([
                'status' => 'error',
                'message' => 'غير مصرح لك بالوصول إلى هذا الطلب'
            ], 403);
        }
        
        return response()->json([
            'status' => 'success',
            'data' => $leaveRequest
        ]);
    }

    /**
     * الموافقة على طلب إجازة
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function approve(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'comments' => 'nullable|string|max:500',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => 'بيانات غير صالحة',
                'errors' => $validator->errors()
            ], 422);
        }

        $user = Auth::user();
        $leaveRequest = LeaveRequest::find($id);
        
        if (!$leaveRequest) {
            return response()->json([
                'status' => 'error',
                'message' => 'طلب الإجازة غير موجود'
            ], 404);
        }
        
        // التحقق من الصلاحيات
        if (!$user->isManager()) {
            return response()->json([
                'status' => 'error',
                'message' => 'غير مصرح لك بالموافقة على طلبات الإجازة'
            ], 403);
        }
        
        // التحقق من حالة الطلب
        if ($leaveRequest->status !== 'pending') {
            return response()->json([
                'status' => 'error',
                'message' => 'لا يمكن الموافقة على طلب تمت معالجته مسبقاً'
            ], 400);
        }
        
        // تحديد المرحلة الحالية للموافقة
        $currentStage = $leaveRequest->getCurrentApprovalStage();
        
        if (!$currentStage) {
            return response()->json([
                'status' => 'error',
                'message' => 'لا توجد مرحلة موافقة حالية'
            ], 400);
        }
        
        // التحقق من صلاحية الموافقة على المرحلة الحالية
        $canApprove = false;
        
        if ($currentStage->stage_name === 'موافقة المدير المباشر' && 
            $leaveRequest->user->manager_id === $user->user_id) {
            $canApprove = true;
        } elseif ($currentStage->stage_name === 'موافقة رئيس القسم' && 
                 $leaveRequest->user->department->head_id === $user->user_id) {
            $canApprove = true;
        } elseif ($currentStage->stage_name === 'موافقة الموارد البشرية' && 
                 $user->isHrManager()) {
            $canApprove = true;
        }
        
        if (!$canApprove) {
            return response()->json([
                'status' => 'error',
                'message' => 'غير مصرح لك بالموافقة على هذه المرحلة'
            ], 403);
        }
        
        // تحديث سجل الموافقة
        $approval = ApprovalHistory::where('request_id', $leaveRequest->request_id)
            ->where('stage_id', $currentStage->stage_id)
            ->where('status', 'pending')
            ->first();
        
        if ($approval) {
            $approval->approver_id = $user->user_id;
            $approval->status = 'approved';
            $approval->comments = $request->comments;
            $approval->action_date = now();
            $approval->save();
            
            // التحقق من المرحلة التالية
            $nextStage = $currentStage->getNextStage();
            
            if ($nextStage) {
                // إنشاء سجل موافقة للمرحلة التالية
                $nextApprover = null;
                
                if ($nextStage->stage_name === 'موافقة رئيس القسم') {
                    $nextApprover = $leaveRequest->user->department->head_id;
                } elseif ($nextStage->stage_name === 'موافقة الموارد البشرية') {
                    // تعيين أول مدير موارد بشرية كموافق
                    $hrManager = User::whereHas('role', function($query) {
                        $query->where('role_name', 'hr_manager');
                    })->first();
                    
                    if ($hrManager) {
                        $nextApprover = $hrManager->user_id;
                    }
                }
                
                if ($nextApprover) {
                    $nextApproval = new ApprovalHistory([
                        'request_id' => $leaveRequest->request_id,
                        'stage_id' => $nextStage->stage_id,
                        'approver_id' => $nextApprover,
                        'status' => 'pending'
                    ]);
                    
                    $nextApproval->save();
                    
                    // إرسال إشعار للموافق التالي
                    $notification = new Notification([
                        'user_id' => $nextApprover,
                        'title' => 'طلب إجازة يحتاج إلى موافقة',
                        'message' => 'هناك طلب إجازة من ' . $leaveRequest->user->full_name . ' يحتاج إلى موافقتك',
                        'related_to' => 'leave_request',
                        'related_id' => $leaveRequest->request_id,
                        'is_read' => false
                    ]);
                    
                    $notification->save();
                }
            } else {
                // الموافقة النهائية على الطلب
                $leaveRequest->status = 'approved';
                $leaveRequest->save();
                
                // تحديث رصيد الإجازة
                if ($leaveRequest->leaveType->is_paid) {
                    $leaveBalance = LeaveBalance::where('user_id', $leaveRequest->user_id)
                        ->where('leave_type_id', $leaveRequest->leave_type_id)
                        ->where('year', date('Y', strtotime($leaveRequest->start_date)))
                        ->first();
                    
                    if ($leaveBalance) {
                        $leaveBalance->deductDays($leaveRequest->total_days);
                    }
                }
                
                // إرسال إشعار للموظف
                $notification = new Notification([
                    'user_id' => $leaveRequest->user_id,
                    'title' => 'تمت الموافقة على طلب الإجازة',
                    'message' => 'تمت الموافقة على طلب الإجازة الخاص بك من ' . $leaveRequest->start_date . ' إلى ' . $leaveRequest->end_date,
                    'related_to' => 'leave_request',
                    'related_id' => $leaveRequest->request_id,
                    'is_read' => false
                ]);
                
                $notification->save();
            }
            
            return response()->json([
                'status' => 'success',
                'message' => 'تمت الموافقة على طلب الإجازة بنجاح',
                'data' => $leaveRequest
            ]);
        }
        
        return response()->json([
            'status' => 'error',
            'message' => 'لم يتم العثور على سجل الموافقة'
        ], 404);
    }

    /**
     * رفض طلب إجازة
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function reject(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'comments' => 'required|string|max:500',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => 'بيانات غير صالحة',
                'errors' => $validator->errors()
            ], 422);
        }

        $user = Auth::user();
        $leaveRequest = LeaveRequest::find($id);
        
        if (!$leaveRequest) {
            return response()->json([
                'status' => 'error',
                'message' => 'طلب الإجازة غير موجود'
            ], 404);
        }
        
        // التحقق من الصلاحيات والمرحلة الحالية (نفس منطق الموافقة)
        // ...
        
        // تحديث سجل الموافقة
        $currentStage = $leaveRequest->getCurrentApprovalStage();
        
        if (!$currentStage) {
            return response()->json([
                'status' => 'error',
                'message' => 'لا توجد مرحلة موافقة حالية'
            ], 400);
        }
        
        $approval = ApprovalHistory::where('request_id', $leaveRequest->request_id)
            ->where('stage_id', $currentStage->stage_id)
            ->where('status', 'pending')
            ->first();
        
        if ($approval) {
            $approval->approver_id = $user->user_id;
            $approval->status = 'rejected';
            $approval->comments = $request->comments;
            $approval->action_date = now();
            $approval->save();
            
            // تحديث حالة الطلب
            $leaveRequest->status = 'rejected';
            $leaveRequest->save();
            
            // إرسال إشعار للموظف
            $notification = new Notification([
                'user_id' => $leaveRequest->user_id,
                'title' => 'تم رفض طلب الإجازة',
                'message' => 'تم رفض طلب الإجازة الخاص بك. السبب: ' . $request->comments,
                'related_to' => 'leave_request',
                'related_id' => $leaveRequest->request_id,
                'is_read' => false
            ]);
            
            $notification->save();
            
            return response()->json([
                'status' => 'success',
                'message' => 'تم رفض طلب الإجازة بنجاح',
                'data' => $leaveRequest
            ]);
        }
        
        return response()->json([
            'status' => 'error',
            'message' => 'لم يتم العثور على سجل الموافقة'
        ], 404);
    }

    /**
     * إلغاء طلب إجازة
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function cancel($id)
    {
        $user = Auth::user();
        $leaveRequest = LeaveRequest::find($id);
        
        if (!$leaveRequest) {
            return response()->json([
                'status' => 'error',
                'message' => 'طلب الإجازة غير موجود'
            ], 404);
        }
        
        // التحقق من ملكية الطلب
        if ($leaveRequest->user_id !== $user->user_id) {
            return response()->json([
                'status' => 'error',
                'message' => 'غير مصرح لك بإلغاء هذا الطلب'
            ], 403);
        }
        
        // التحقق من حالة الطلب
        if ($leaveRequest->status !== 'pending') {
            return response()->json([
                'status' => 'error',
                'message' => 'لا يمكن إلغاء طلب تمت معالجته مسبقاً'
            ], 400);
        }
        
        // تحديث حالة الطلب
        $leaveRequest->status = 'cancelled';
        $leaveRequest->save();
        
        // إلغاء جميع سجلات الموافقة المعلقة
        ApprovalHistory::where('request_id', $leaveRequest->request_id)
            ->where('status', 'pending')
            ->update(['status' => 'cancelled']);
        
        return response()->json([
            'status' => 'success',
            'message' => 'تم إلغاء طلب الإجازة بنجاح',
            'data' => $leaveRequest
        ]);
    }
}
