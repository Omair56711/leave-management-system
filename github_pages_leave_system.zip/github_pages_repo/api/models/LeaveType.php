<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LeaveType extends Model
{
    /**
     * الجدول المرتبط بالنموذج
     *
     * @var string
     */
    protected $table = 'leave_types';

    /**
     * المفتاح الأساسي للجدول
     *
     * @var string
     */
    protected $primaryKey = 'leave_type_id';

    /**
     * الخصائص التي يمكن تعيينها بشكل جماعي
     *
     * @var array
     */
    protected $fillable = [
        'type_name',
        'description',
        'default_days',
        'is_paid',
        'requires_attachment'
    ];

    /**
     * تحويل الخصائص إلى أنواع بيانات محددة
     *
     * @var array
     */
    protected $casts = [
        'is_paid' => 'boolean',
        'requires_attachment' => 'boolean',
        'default_days' => 'integer'
    ];

    /**
     * العلاقة مع جدول طلبات الإجازة
     */
    public function leaveRequests()
    {
        return $this->hasMany(LeaveRequest::class, 'leave_type_id');
    }

    /**
     * العلاقة مع جدول أرصدة الإجازات
     */
    public function leaveBalances()
    {
        return $this->hasMany(LeaveBalance::class, 'leave_type_id');
    }
}
