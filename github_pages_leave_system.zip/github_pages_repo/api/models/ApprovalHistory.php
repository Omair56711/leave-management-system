<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ApprovalHistory extends Model
{
    /**
     * الجدول المرتبط بالنموذج
     *
     * @var string
     */
    protected $table = 'approval_history';

    /**
     * المفتاح الأساسي للجدول
     *
     * @var string
     */
    protected $primaryKey = 'approval_id';

    /**
     * الخصائص التي يمكن تعيينها بشكل جماعي
     *
     * @var array
     */
    protected $fillable = [
        'request_id',
        'stage_id',
        'approver_id',
        'status',
        'comments',
        'action_date'
    ];

    /**
     * تحويل الخصائص إلى أنواع بيانات محددة
     *
     * @var array
     */
    protected $casts = [
        'action_date' => 'datetime'
    ];

    /**
     * العلاقة مع جدول طلبات الإجازة
     */
    public function leaveRequest()
    {
        return $this->belongsTo(LeaveRequest::class, 'request_id');
    }

    /**
     * العلاقة مع جدول مراحل الموافقة
     */
    public function stage()
    {
        return $this->belongsTo(ApprovalStage::class, 'stage_id');
    }

    /**
     * العلاقة مع جدول المستخدمين (الموافق)
     */
    public function approver()
    {
        return $this->belongsTo(User::class, 'approver_id');
    }

    /**
     * التحقق مما إذا كانت الموافقة قيد الانتظار
     */
    public function isPending()
    {
        return $this->status === 'pending';
    }

    /**
     * التحقق مما إذا كانت الموافقة تمت
     */
    public function isApproved()
    {
        return $this->status === 'approved';
    }

    /**
     * التحقق مما إذا كانت الموافقة تم رفضها
     */
    public function isRejected()
    {
        return $this->status === 'rejected';
    }
}
