<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ApprovalStage extends Model
{
    /**
     * الجدول المرتبط بالنموذج
     *
     * @var string
     */
    protected $table = 'approval_stages';

    /**
     * المفتاح الأساسي للجدول
     *
     * @var string
     */
    protected $primaryKey = 'stage_id';

    /**
     * الخصائص التي يمكن تعيينها بشكل جماعي
     *
     * @var array
     */
    protected $fillable = [
        'stage_name',
        'description',
        'order_num'
    ];

    /**
     * تحويل الخصائص إلى أنواع بيانات محددة
     *
     * @var array
     */
    protected $casts = [
        'order_num' => 'integer'
    ];

    /**
     * العلاقة مع جدول سجل الموافقات
     */
    public function approvalHistory()
    {
        return $this->hasMany(ApprovalHistory::class, 'stage_id');
    }

    /**
     * الحصول على المرحلة التالية
     */
    public function getNextStage()
    {
        return ApprovalStage::where('order_num', '>', $this->order_num)
            ->orderBy('order_num', 'asc')
            ->first();
    }

    /**
     * الحصول على المرحلة السابقة
     */
    public function getPreviousStage()
    {
        return ApprovalStage::where('order_num', '<', $this->order_num)
            ->orderBy('order_num', 'desc')
            ->first();
    }
}
