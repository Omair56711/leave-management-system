<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LeaveBalance extends Model
{
    /**
     * الجدول المرتبط بالنموذج
     *
     * @var string
     */
    protected $table = 'leave_balances';

    /**
     * المفتاح الأساسي للجدول
     *
     * @var string
     */
    protected $primaryKey = 'balance_id';

    /**
     * الخصائص التي يمكن تعيينها بشكل جماعي
     *
     * @var array
     */
    protected $fillable = [
        'user_id',
        'leave_type_id',
        'year',
        'total_days',
        'used_days',
        'remaining_days',
        'carried_over'
    ];

    /**
     * تحويل الخصائص إلى أنواع بيانات محددة
     *
     * @var array
     */
    protected $casts = [
        'year' => 'integer',
        'total_days' => 'decimal:1',
        'used_days' => 'decimal:1',
        'remaining_days' => 'decimal:1',
        'carried_over' => 'decimal:1'
    ];

    /**
     * العلاقة مع جدول المستخدمين
     */
    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    /**
     * العلاقة مع جدول أنواع الإجازات
     */
    public function leaveType()
    {
        return $this->belongsTo(LeaveType::class, 'leave_type_id');
    }

    /**
     * تحديث رصيد الإجازة بعد الموافقة على طلب إجازة
     *
     * @param float $days
     * @return bool
     */
    public function deductDays($days)
    {
        if ($this->remaining_days >= $days) {
            $this->used_days += $days;
            $this->remaining_days -= $days;
            return $this->save();
        }
        return false;
    }

    /**
     * إعادة رصيد الإجازة بعد إلغاء طلب إجازة
     *
     * @param float $days
     * @return bool
     */
    public function addDays($days)
    {
        $this->used_days -= $days;
        $this->remaining_days += $days;
        return $this->save();
    }
}
