<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Notification extends Model
{
    /**
     * الجدول المرتبط بالنموذج
     *
     * @var string
     */
    protected $table = 'notifications';

    /**
     * المفتاح الأساسي للجدول
     *
     * @var string
     */
    protected $primaryKey = 'notification_id';

    /**
     * الخصائص التي يمكن تعيينها بشكل جماعي
     *
     * @var array
     */
    protected $fillable = [
        'user_id',
        'title',
        'message',
        'related_to',
        'related_id',
        'is_read'
    ];

    /**
     * تحويل الخصائص إلى أنواع بيانات محددة
     *
     * @var array
     */
    protected $casts = [
        'is_read' => 'boolean'
    ];

    /**
     * العلاقة مع جدول المستخدمين
     */
    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    /**
     * الحصول على العنصر المرتبط بالإشعار
     */
    public function getRelatedItem()
    {
        if ($this->related_to === 'leave_request') {
            return LeaveRequest::find($this->related_id);
        } elseif ($this->related_to === 'approval') {
            return ApprovalHistory::find($this->related_id);
        }
        return null;
    }

    /**
     * تحديث حالة الإشعار إلى مقروء
     */
    public function markAsRead()
    {
        $this->is_read = true;
        return $this->save();
    }
}
