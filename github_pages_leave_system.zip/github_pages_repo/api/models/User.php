<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * الجدول المرتبط بالنموذج
     *
     * @var string
     */
    protected $table = 'users';

    /**
     * المفتاح الأساسي للجدول
     *
     * @var string
     */
    protected $primaryKey = 'user_id';

    /**
     * الخصائص التي يمكن تعيينها بشكل جماعي
     *
     * @var array
     */
    protected $fillable = [
        'username',
        'password',
        'email',
        'full_name',
        'role_id',
        'department_id',
        'manager_id',
        'join_date',
        'status'
    ];

    /**
     * الخصائص التي يجب إخفاؤها في المصفوفات
     *
     * @var array
     */
    protected $hidden = [
        'password',
    ];

    /**
     * تحويل الخصائص إلى أنواع بيانات محددة
     *
     * @var array
     */
    protected $casts = [
        'join_date' => 'date',
    ];

    /**
     * العلاقة مع جدول الأدوار
     */
    public function role()
    {
        return $this->belongsTo(Role::class, 'role_id');
    }

    /**
     * العلاقة مع جدول الأقسام
     */
    public function department()
    {
        return $this->belongsTo(Department::class, 'department_id');
    }

    /**
     * العلاقة مع المدير المباشر
     */
    public function manager()
    {
        return $this->belongsTo(User::class, 'manager_id');
    }

    /**
     * العلاقة مع الموظفين التابعين
     */
    public function subordinates()
    {
        return $this->hasMany(User::class, 'manager_id');
    }

    /**
     * العلاقة مع جدول أرصدة الإجازات
     */
    public function leaveBalances()
    {
        return $this->hasMany(LeaveBalance::class, 'user_id');
    }

    /**
     * العلاقة مع جدول طلبات الإجازة
     */
    public function leaveRequests()
    {
        return $this->hasMany(LeaveRequest::class, 'user_id');
    }

    /**
     * العلاقة مع جدول الإشعارات
     */
    public function notifications()
    {
        return $this->hasMany(Notification::class, 'user_id');
    }

    /**
     * التحقق مما إذا كان المستخدم مديراً
     */
    public function isManager()
    {
        return in_array($this->role->role_name, ['manager', 'department_head', 'hr_manager', 'admin']);
    }

    /**
     * التحقق مما إذا كان المستخدم مدير موارد بشرية
     */
    public function isHrManager()
    {
        return in_array($this->role->role_name, ['hr_manager', 'admin']);
    }

    /**
     * التحقق مما إذا كان المستخدم مسؤول نظام
     */
    public function isAdmin()
    {
        return $this->role->role_name === 'admin';
    }
}
