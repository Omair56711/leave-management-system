<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LeaveRequest extends Model
{
    /**
     * الجدول المرتبط بالنموذج
     *
     * @var string
     */
    protected $table = 'leave_requests';

    /**
     * المفتاح الأساسي للجدول
     *
     * @var string
     */
    protected $primaryKey = 'request_id';

    /**
     * الخصائص التي يمكن تعيينها بشكل جماعي
     *
     * @var array
     */
    protected $fillable = [
        'user_id',
        'leave_type_id',
        'start_date',
        'end_date',
        'total_days',
        'reason',
        'attachment_path',
        'status'
    ];

    /**
     * تحويل الخصائص إلى أنواع بيانات محددة
     *
     * @var array
     */
    protected $casts = [
        'start_date' => 'date',
        'end_date' => 'date',
        'total_days' => 'decimal:1'
    ];

    /**
     * العلاقة مع جدول المستخدمين
     */
    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    /**
     * العلاقة مع جدول أنواع الإجازات
     */
    public function leaveType()
    {
        return $this->belongsTo(LeaveType::class, 'leave_type_id');
    }

    /**
     * العلاقة مع جدول سجل الموافقات
     */
    public function approvals()
    {
        return $this->hasMany(ApprovalHistory::class, 'request_id');
    }

    /**
     * العلاقة مع جدول الإشعارات
     */
    public function notifications()
    {
        return $this->hasMany(Notification::class, 'related_id')->where('related_to', 'leave_request');
    }

    /**
     * التحقق مما إذا كان طلب الإجازة قيد الانتظار
     */
    public function isPending()
    {
        return $this->status === 'pending';
    }

    /**
     * التحقق مما إذا كان طلب الإجازة تمت الموافقة عليه
     */
    public function isApproved()
    {
        return $this->status === 'approved';
    }

    /**
     * التحقق مما إذا كان طلب الإجازة تم رفضه
     */
    public function isRejected()
    {
        return $this->status === 'rejected';
    }

    /**
     * التحقق مما إذا كان طلب الإجازة تم إلغاؤه
     */
    public function isCancelled()
    {
        return $this->status === 'cancelled';
    }

    /**
     * الحصول على المرحلة الحالية للموافقة
     */
    public function getCurrentApprovalStage()
    {
        $pendingApproval = $this->approvals()->where('status', 'pending')->orderBy('stage_id', 'asc')->first();
        return $pendingApproval ? $pendingApproval->stage : null;
    }
}
