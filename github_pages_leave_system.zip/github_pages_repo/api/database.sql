-- إنشاء قاعدة بيانات نظام إدارة الإجازات
CREATE DATABASE IF NOT EXISTS leave_management_system;
USE leave_management_system;

-- جدول الأدوار
CREATE TABLE roles (
    role_id INT AUTO_INCREMENT PRIMARY KEY,
    role_name VARCHAR(50) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- جدول الأقسام
CREATE TABLE departments (
    department_id INT AUTO_INCREMENT PRIMARY KEY,
    department_name VARCHAR(100) NOT NULL,
    description TEXT,
    head_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- جدول المستخدمين
CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    full_name VARCHAR(100) NOT NULL,
    role_id INT NOT NULL,
    department_id INT NOT NULL,
    manager_id INT,
    join_date DATE NOT NULL,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (role_id) REFERENCES roles(role_id),
    FOREIGN KEY (department_id) REFERENCES departments(department_id),
    FOREIGN KEY (manager_id) REFERENCES users(user_id)
);

-- تحديث جدول الأقسام لإضافة المفتاح الخارجي لرئيس القسم
ALTER TABLE departments
ADD CONSTRAINT fk_department_head
FOREIGN KEY (head_id) REFERENCES users(user_id);

-- جدول أنواع الإجازات
CREATE TABLE leave_types (
    leave_type_id INT AUTO_INCREMENT PRIMARY KEY,
    type_name VARCHAR(50) NOT NULL,
    description TEXT,
    default_days INT NOT NULL,
    is_paid BOOLEAN DEFAULT TRUE,
    requires_attachment BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- جدول أرصدة الإجازات
CREATE TABLE leave_balances (
    balance_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    leave_type_id INT NOT NULL,
    year INT NOT NULL,
    total_days DECIMAL(5,1) NOT NULL,
    used_days DECIMAL(5,1) DEFAULT 0,
    remaining_days DECIMAL(5,1) NOT NULL,
    carried_over DECIMAL(5,1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (leave_type_id) REFERENCES leave_types(leave_type_id),
    UNIQUE KEY unique_balance (user_id, leave_type_id, year)
);

-- جدول طلبات الإجازة
CREATE TABLE leave_requests (
    request_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    leave_type_id INT NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    total_days DECIMAL(5,1) NOT NULL,
    reason TEXT,
    attachment_path VARCHAR(255),
    status ENUM('pending', 'approved', 'rejected', 'cancelled') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (leave_type_id) REFERENCES leave_types(leave_type_id)
);

-- جدول مراحل الموافقة
CREATE TABLE approval_stages (
    stage_id INT AUTO_INCREMENT PRIMARY KEY,
    stage_name VARCHAR(100) NOT NULL,
    description TEXT,
    order_num INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- جدول سجل الموافقات
CREATE TABLE approval_history (
    approval_id INT AUTO_INCREMENT PRIMARY KEY,
    request_id INT NOT NULL,
    stage_id INT NOT NULL,
    approver_id INT NOT NULL,
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    comments TEXT,
    action_date TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (request_id) REFERENCES leave_requests(request_id),
    FOREIGN KEY (stage_id) REFERENCES approval_stages(stage_id),
    FOREIGN KEY (approver_id) REFERENCES users(user_id)
);

-- جدول الإشعارات
CREATE TABLE notifications (
    notification_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    title VARCHAR(100) NOT NULL,
    message TEXT NOT NULL,
    related_to ENUM('leave_request', 'approval') NOT NULL,
    related_id INT NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- جدول سجل النظام
CREATE TABLE system_logs (
    log_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    action VARCHAR(100) NOT NULL,
    description TEXT,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- إدخال بيانات أولية

-- إدخال الأدوار
INSERT INTO roles (role_name, description) VALUES
('admin', 'مسؤول النظام مع صلاحيات كاملة'),
('hr_manager', 'مدير الموارد البشرية'),
('department_head', 'رئيس قسم'),
('manager', 'مدير'),
('employee', 'موظف');

-- إدخال الأقسام
INSERT INTO departments (department_name, description) VALUES
('الإدارة', 'الإدارة العليا'),
('الموارد البشرية', 'قسم الموارد البشرية'),
('تكنولوجيا المعلومات', 'قسم تكنولوجيا المعلومات'),
('المالية', 'قسم المالية'),
('التسويق', 'قسم التسويق');

-- إدخال أنواع الإجازات
INSERT INTO leave_types (type_name, description, default_days, is_paid, requires_attachment) VALUES
('سنوية', 'الإجازة السنوية المدفوعة', 21, TRUE, FALSE),
('مرضية', 'إجازة مرضية', 14, TRUE, TRUE),
('طارئة', 'إجازة للحالات الطارئة', 7, TRUE, FALSE),
('أمومة', 'إجازة أمومة', 90, TRUE, TRUE),
('بدون راتب', 'إجازة غير مدفوعة', 30, FALSE, FALSE);

-- إدخال مراحل الموافقة
INSERT INTO approval_stages (stage_name, description, order_num) VALUES
('موافقة المدير المباشر', 'مرحلة موافقة المدير المباشر', 1),
('موافقة رئيس القسم', 'مرحلة موافقة رئيس القسم', 2),
('موافقة الموارد البشرية', 'مرحلة موافقة مدير الموارد البشرية', 3);
